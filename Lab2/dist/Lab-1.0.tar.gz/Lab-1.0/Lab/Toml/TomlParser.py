from typing import Any, IO # pragma: no cover
import toml
from logic.dictmaker import *

class TomlParser:
    unpacker = ToDict()
    packer = FromDict()

    def dump(self, obj: object, file: object = None, unpacked=True) -> None: 
        packed_obj = self.unpacker.pack_to_dict(obj)
        if file:
            with open(file, 'w') as file:
                toml.dump(packed_obj,file)
        else: 
            raise ValueError("File transfer aborted")

    def dumps(self, obj: object) -> None: 
        return toml.dumps(self.unpacker.pack_to_dict(obj))

    def load(self, file: object, unpack=True) -> Any: 
        if file:
            with open(file, 'r') as file:
                return self.packer.unpack_from_dict(toml.load(file))
        else:
            raise ValueError("File transfer aborted")

    def loads(self, string: str) -> Any: 
        return packer.unpack_from_dict(toml.loads(string))